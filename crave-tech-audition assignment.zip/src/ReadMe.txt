To start the project, 
first install the dependences. run "npm install" on the root directory
then run npm start