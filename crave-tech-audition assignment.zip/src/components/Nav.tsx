import React from 'react'

const Nav = () => {
  return (
    <div className='text-green-500'>
        <p className='bg-blue-700 text-xl text-white uppercase text-center py-6'>Startup Process tracker</p>
    </div>
  )
}

export default Nav